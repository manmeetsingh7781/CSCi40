// Recursion.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iostream>
using namespace std;

// Function prototypes
int factorial(int);
int GCF(int, int);

// unsigned means these values can not store any negative number.. because we do not need any negaive numbers and also the storage limit of int has been increased 
unsigned int sum_factorial = 1, start = 1, number_to_divide = 12, greatest_cm, temp_gcf;



int main() {
	cout << GCF(12, 16);
	return 0;
}

// function takes one number and gets the factor of it until the number is 1
int factorial(int number) {
	if (number != 1) {
		sum_factorial *= number;
		return factorial(number-1);
	}
	return sum_factorial;
}


int GCF(int divider1, int divider2) {


  if(divider1 <= 0 and divider2 >= 1){
    cout << "GCF is ";
    return divider2;
  }

  if(divider2 <= 0 and divider1 >= 1){
    cout << "GCF is ";
    return divider1;
  }

  if(divider1 <= 0 or divider2 <= 0){
    cout << "GCF is ";
    return divider1 + divider2;
  }

	if (start != (divider1+1) and start != (divider2+1)) {
  
  if(divider1 % start == 0){
      cout << divider1  << " -> " << start << endl;
  }

  if(divider2 % start == 0){
       cout << divider2 << " -> " << start << endl;
  }
  
  if(divider2 % start == 0 and divider1 % start == 0){
     greatest_cm = start;
     temp_gcf = greatest_cm; 
  }

  // in case if we have the greater factor then we can assign it to the original number 
 if(temp_gcf > greatest_cm){
    greatest_cm = temp_gcf;
  }

  start +=1;
  return GCF(divider1, divider2);
  }

  cout << "GCF is ";
  return greatest_cm;
}