// Recursion.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iostream>
using namespace std;

int factorial(int);
int sum_factorial = 1, start = 1, number_to_divide = 12, greatest_cm, temp_gcf;

int GCF(int, int);

int main() {
	cout << GCF(1024, 512);
	return 0;
}

// Max 19 int;
int factorial(int number) {
	if (number != 1) {
		sum_factorial *= number;
		number -= 1;
		return factorial(number);
	}
	return sum_factorial;
}

int GCF(int divider1, int divider2) {

	if (start != (divider1+1) and start != (divider2+1)) {
  
  if(divider1 % start == 0){
      cout << start << " -> " << divider1 << endl;
  }

  if(divider2 % start == 0){
       cout << start << " -> " << divider2 << endl;
  }
  
  if(divider2 % start == 0 and divider1 % start == 0){
     greatest_cm = start;
     temp_gcf = greatest_cm; 
  }

 if(temp_gcf > greatest_cm){
    greatest_cm = temp_gcf;
  }

  start +=1;
  return GCF(divider1, divider2);
  
  }
  cout << "GCF is ";
  return greatest_cm;
}
