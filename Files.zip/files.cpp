// Manmeet Singh
// This programs sorts the named list in A-Z order


#include <iostream>
#include <fstream>
using namespace  std;

// Function prototypes
void readFile(string);
void createFile(string);
void writeFile(string, string);
void sort(string[], int);
void getFileSize(string);

// variable Declarations 
string line;
int counter = 0, sorter = 0, user_input ;
char letter;
int *size;
string * names;


int main(){
// Gets the number of words in file and creates a array based words   
getFileSize("names.txt");

// Sets the size of array 
size = &user_input;

// Creating a array to store words from file 
names = new string [*size];

// Reading the file and saving in array 
readFile("names.txt");

// Sorting the array 
sort(names, *size);  

// Take words out from array and writing it in the file 
while(sorter != *size){
  writeFile("sorted_names.txt", names[sorter] + "\n");
  sorter++;
  if(sorter == *size){
    cout << "Sorting has been completed. And file has been created"<< endl;
  }
 }
  return 0;
}

// This function get's the file lines and create an array for it
void getFileSize(string name){
    fstream file(name);
    while (getline(file, line)) {
    user_input++;
    }
}

// Creates a New file 
void createFile(string name) {
	fstream file(name);
	cout << "File has been created " << name << endl;
}


// Writes a file.. It takes two parameters first one is the target and second is what to write

void writeFile(string name, string text) {
  // ios::app this function appends the text into the file rather then erasing and writing it.
	fstream file(name, ios::app);
	if (file) {
		file << text;
		file.flush();
		file.close();
	}
	else {
    // if file not found then it will create a new file
		createFile(name);
	}
}

// This function reads the file first 
void readFile(string name) {
fstream file(name);
while (getline(file, line)) {
    // Filling up the array of words from file
  names[counter] = line;
  counter++;
}
	file.close();
}

// A function to implement bubble sort or words
void sort(string arr[], int size) 
{ 
 int number = 0, start, y;
 string temp; 
 char smaller, bigger;
 for(start = 0; start <= size; start++){
   number++;

   // Here I am checking words pair by pair 
   for(y = 0; y < size - number; y++){
     smaller = arr[y][0]; // each first letter of word
     bigger  = arr[y+1][0];
     
     // switching the words in order
   if(smaller > bigger){
    temp = arr[y];
    arr[y] = arr[y+1];
    arr[y+1] = temp;
   }
   }
 }
}